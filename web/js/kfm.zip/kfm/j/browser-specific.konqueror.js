
function clearSelections(e){}