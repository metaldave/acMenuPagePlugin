
window.kfm_showMessage=function(message){new Notice(message);}