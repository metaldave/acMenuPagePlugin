
window.kfm_extractZippedFile=function(id){x_kfm_extractZippedFile(id,kfm_refreshFiles);}