<?php
$p = new kfmPlugin('directories_max_image_size');
$kfm->addPlugin($p);
?>
