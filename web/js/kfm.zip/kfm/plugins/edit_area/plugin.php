<?php
$p=new kfmPlugin('edit_area');
$kfm->addPlugin($p);
?>
