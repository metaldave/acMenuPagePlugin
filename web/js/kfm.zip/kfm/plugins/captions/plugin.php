<?php
$p=new kfmPlugin('captions');
$kfm->addPlugin($p);
?>
