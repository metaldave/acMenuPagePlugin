<?php
$p=new kfmPlugin('image_resize');
$kfm->addPlugin($p);
?>
