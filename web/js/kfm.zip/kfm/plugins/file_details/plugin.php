<?php
$p=new kfmPlugin('file_details');
$kfm->addPlugin($p);
?>
