<?php
$p=new kfmPlugin('image_rotate');
$kfm->addPlugin($p);
?>
