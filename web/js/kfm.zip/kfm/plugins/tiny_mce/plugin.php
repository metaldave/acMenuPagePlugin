<?php
$p=new kfmPlugin('tiny_mce');
$kfm->addPlugin($p);
?>
