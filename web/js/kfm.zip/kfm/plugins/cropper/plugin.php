<?php
$p=new kfmPlugin('cropper');
$kfm->addPlugin($p);
?>
