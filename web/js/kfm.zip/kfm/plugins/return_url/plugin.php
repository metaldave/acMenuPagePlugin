<?php
$p=new kfmPlugin('return_url');
$kfm->addPlugin($p);
?>
