KFM - Kae's File Manager

LICENSE and VERSION
see version.txt for version
see license.txt for licensing

INSTALLATION
http://kfm.verens.com/documentation

INFORMATION
http://kfm.verens.com/

BUGS AND FEATURES
http://mantis.verens.com/

FORUM
http://kfm.verens.com/phpBB3/
